package miembros;

public class Estudiante extends Persona{
    private String carrera;
    private double promedio;

    public Estudiante(String carrera, double promedio, String documento, 
            String nombre, String direccion, String fechaNacimiento, char sexo) {
        super(documento, nombre, direccion, fechaNacimiento, sexo);
        this.carrera = carrera;
        this.promedio = promedio;
    }

    @Override
    public String toString() {
        return super.toString() 
                + " | " + carrera 
                + " | " + promedio 
                + " | ";
    }

    public String getCarrera() {
        return carrera;
    }

    public void setCarrera(String carrera) {
        this.carrera = carrera;
    }

    public double getPromedio() {
        return promedio;
    }

    public void setPromedio(double promedio) {
        this.promedio = promedio;
    }
    
    
}
