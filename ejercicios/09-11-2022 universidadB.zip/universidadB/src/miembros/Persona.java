package miembros;

public class Persona {
    protected String documento;
    protected String nombre;
    protected String direccion;
    protected String fechaNacimiento;
    protected char sexo;

    public Persona(String documento, String nombre, String direccion, 
            String fechaNacimiento, char sexo) {
        this.documento = documento;
        this.nombre = nombre;
        this.direccion = direccion;
        this.fechaNacimiento = fechaNacimiento;
        this.sexo = sexo;
    }
    
    

    @Override
    public String toString() {
        return    " | " + documento 
                + " | " + nombre 
                + " | " + direccion 
                + " | " + fechaNacimiento 
                + " | " + sexo;
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(String fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public char getSexo() {
        return sexo;
    }

    public void setSexo(char sexo) {
        this.sexo = sexo;
    }
    
    
}
