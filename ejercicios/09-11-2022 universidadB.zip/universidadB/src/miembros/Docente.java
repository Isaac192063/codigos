package miembros;

public class Docente extends Persona{
    private double salario;
    private String titulo;

    public Docente(double salario, String titulo, String documento, 
            String nombre, String direccion, String fechaNacimiento, char sexo) {
        super(documento, nombre, direccion, fechaNacimiento, sexo);
        this.salario = salario;
        this.titulo = titulo;
    }

    @Override
    public String toString() {
        return super.toString()
                + " | " + salario 
                + " | " + titulo 
                + " | ";
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
    
    
}
