package universidadb;
import gestion.GestionPersona;

public class Principal {

    public static void main(String[] args) {
        GestionPersona gestion = new GestionPersona();
        gestion.menu();
    }
    
}
